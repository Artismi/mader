'use client'

import { useEffect, useState, type ReactNode } from 'react'
import { Brain, Database, Zap, Sparkles, History, Activity, FolderSearch, LayoutDashboard, Copy, Info } from 'lucide-react'
import { VaultBrowser } from './vault-browser'
import { ArchitectureEditor } from './architecture-editor'
import { MemoryManager } from './memory-manager'
import { cn } from '@/lib/utils'

interface SnapshotData {
  snapshot: string
  ragCount: number
  memoryCount: number
  timestamp: string
  skills?: { name: string; active: boolean; triggers: string[] }[]
  recentActivities?: string[]
}

export function CervelloDashboard() {
  const [data, setData] = useState<SnapshotData | null>(null)
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState<'hub' | 'advanced'>('hub')

  const fetchContext = async () => {
    try {
      const res = await fetch('/api/ai/context')
      if (!res.ok) throw new Error('API request failed')
      const d = await res.json()
      setData(d)
    } catch (err) {
      console.error("Context fetch error:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchContext()
    const interval = setInterval(fetchContext, 60000) // Refresh every 60s
    return () => clearInterval(interval)
  }, [])

  if (loading) return (
    <div className="flex items-center justify-center h-full text-violet-400">
      <Zap className="animate-pulse mr-2" />
      <span className="text-[10px] font-black uppercase tracking-[0.3em]">Assemblando Intelligence Hub...</span>
    </div>
  )

  return (
    <div className="flex flex-col h-full gap-4 overflow-hidden">
      
      {/* Header Stat Bar */}
      <div className="flex items-center justify-between px-2">
         <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                 <span className="text-[10px] font-black uppercase tracking-widest text-white/40">Motore AI: Co-Pilot (Claude o Gemini)</span>
            </div>
            <div className="hidden sm:flex items-center gap-4">
                <StatSimple icon={<Database className="w-3 h-3" />} label="RAG Chunks" value={data?.ragCount || 0} />
                <StatSimple icon={<History className="w-3 h-3" />} label="Memorie" value={data?.memoryCount || 0} />
            </div>
         </div>

         <div className="flex bg-white/5 rounded-xl p-1 gap-1 border border-white/5 scale-90 origin-right">
            <button
                onClick={() => setView('hub')}
                className={cn(
                    "flex items-center gap-2 px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all",
                    view === 'hub' ? "bg-white/10 text-white shadow-sm" : "text-white/20 hover:text-white/40"
                )}
            >
                <LayoutDashboard className="w-3.5 h-3.5" /> Intelligence
            </button>
            <button
                onClick={() => setView('advanced')}
                className={cn(
                    "flex items-center gap-2 px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all",
                    view === 'advanced' ? "bg-white/10 text-white shadow-sm" : "text-white/20 hover:text-white/40"
                )}
            >
                <Zap className="w-3.5 h-3.5" /> Core Ops
            </button>
         </div>
      </div>

      <div className="flex-1 min-h-0">
        {view === 'hub' ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 h-full p-2 overflow-hidden">
            
            {/* COLUMN 1: KNOWLEDGE BASE (Vault & Files) */}
            <div className="flex flex-col gap-4 overflow-hidden min-h-0">
                <div className="flex items-center gap-2 px-2">
                    <FolderSearch className="w-4 h-4 text-sky-400" />
                    <h2 className="text-[10px] font-black uppercase tracking-widest text-white/60">Knowledge Base <span className="text-white/10 ml-1">(Obsidian Vault)</span></h2>
                </div>
                <div className="flex-1 min-h-0">
                    <VaultBrowser />
                </div>
            </div>

            {/* COLUMN 2: SYSTEM CORE (Architecture & Skills) */}
            <div className="flex flex-col gap-4 overflow-hidden min-h-0">
                <div className="flex items-center gap-2 px-2">
                    <Zap className="w-4 h-4 text-violet-400" />
                    <h2 className="text-[10px] font-black uppercase tracking-widest text-white/60">System Core <span className="text-white/10 ml-1">(System Prompt)</span></h2>
                </div>
                <div className="flex-[2] min-h-0">
                    <ArchitectureEditor />
                </div>
                <div className="flex-1 min-h-0 bg-black/20 rounded-2xl border border-white/[0.06] overflow-hidden flex flex-col">
                    <div className="px-4 py-3 border-b border-white/[0.06] flex items-center justify-between bg-white/[0.02]">
                        <div className="flex items-center gap-2 text-violet-100 font-medium tracking-widest uppercase text-[10px] text-white/60">
                            <Zap size={14} className="text-yellow-400" />
                            Active Skills status
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-2 scrollbar-hide">
                        {(data?.skills || []).map(s => (
                            <div key={s.name} className="flex items-center justify-between p-2 rounded-lg bg-white/[0.02] border border-white/[0.05]">
                                <div className="flex flex-col">
                                    <span className={cn("text-[10px] font-bold uppercase tracking-widest", s.active ? "text-white/80" : "text-white/20")}>{s.name}</span>
                                    <span className="text-[8px] text-white/10 font-mono italic truncate max-w-[120px]">{s.triggers.join(', ')}</span>
                                </div>
                                <div className={cn("px-2 py-0.5 rounded-full text-[8px] font-black uppercase", s.active ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-white/5 text-white/20 border border-white/10")}>
                                    {s.active ? 'Active' : 'Off'}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* COLUMN 3: EXPERIENCE (Memory & Snapshot) */}
            <div className="flex flex-col gap-4 overflow-hidden min-h-0">
                <div className="flex items-center gap-2 px-2">
                    <Brain className="w-4 h-4 text-fuchsia-400" />
                    <h2 className="text-[10px] font-black uppercase tracking-widest text-white/60">Memory & Situation <span className="text-white/10 ml-1">(Live Context)</span></h2>
                </div>
                <div className="flex-1 min-h-0">
                    <MemoryManager />
                </div>
                <div className="flex-1 min-h-0 bg-black/40 border border-violet-900/40 rounded-2xl flex flex-col overflow-hidden backdrop-blur-xl group">
                    <div className="p-4 border-b border-violet-900/30 flex items-center justify-between bg-violet-900/5">
                        <div className="flex items-center gap-2 text-violet-100 font-medium tracking-widest uppercase text-[10px] text-violet-300">
                            <Activity size={14} className="text-violet-400" />
                            Live Context Briefing
                        </div>
                        <button 
                            onClick={() => { navigator.clipboard.writeText(data?.snapshot || '') }}
                            className="p-1.5 opacity-0 group-hover:opacity-100 hover:bg-white/5 rounded-lg text-white/20 transition-all"
                        >
                            <Copy className="w-3.5 h-3.5" />
                        </button>
                    </div>
                    {data && data.ragCount === 0 && data.memoryCount === 0 && (
                        <p className="px-4 py-2 text-[9px] leading-snug text-amber-400/90 bg-amber-500/5 border-b border-amber-500/15">
                            Anteprima RAG/memorie vuota: servono <span className="font-bold">GEMINI_API_KEY</span> (embedding), <span className="font-bold">vault_path</span> configurato e file <span className="font-bold">.md</span> nel vault; in chat usa il tool <span className="font-bold">remember</span> per le memorie persistenti.
                        </p>
                    )}
                    <div className="flex-1 overflow-y-auto p-4 font-mono text-[10px] leading-relaxed text-slate-400 whitespace-pre-wrap selection:bg-violet-500/30 scrollbar-hide">
                        {data?.snapshot || 'Nessun dato attivo.'}
                    </div>
                </div>
            </div>

          </div>
        ) : (
          /* Advanced Ops View: Debugger & Logs */
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 h-full p-2">
             <div className="bg-black/20 rounded-2xl border border-white/[0.06] p-6 flex flex-col gap-6 overflow-hidden">
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center border border-amber-500/20">
                        <Info className="w-6 h-6 text-amber-500" />
                    </div>
                    <div>
                        <h2 className="text-sm font-black uppercase tracking-widest text-white/90">System Integrity</h2>
                        <p className="text-[10px] text-white/30 tracking-widest font-bold uppercase mt-0.5">Analisi Salute Cervello</p>
                    </div>
                </div>

                <div className="space-y-6">
                    <IntegrityRow label="Dati Operativi (Snapshot)" status="Healthy" score="98%" />
                    <IntegrityRow label="Vault RAG Consistency" status="Active" score={data?.ragCount ? "100%" : "0%"} danger={!data?.ragCount} />
                    <IntegrityRow label="Cognitive Load Efficiency" status="Optimal" score="11ms" />
                    <IntegrityRow label="Persistent Memory Sync" status="Operational" score="8.2MB" />
                </div>

                <div className="mt-auto p-4 rounded-xl bg-white/[0.01] border border-white/[0.05] flex flex-col gap-2">
                    <p className="text-[10px] font-black uppercase tracking-widest text-white/20">Attività di Background</p>
                    <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-hide">
                         {data?.recentActivities?.map((act, i) => (
                            <div key={i} className="text-[10px] font-mono text-white/30 border-l border-white/5 pl-3 py-1">
                                {act}
                            </div>
                         ))}
                    </div>
                </div>
             </div>

             <div className="bg-black/20 rounded-2xl border border-white/[0.06] p-6 flex flex-col items-center justify-center text-center gap-4 group">
                <Sparkles className="w-12 h-12 text-white/5 group-hover:text-accent/20 transition-all duration-500" />
                <div className="space-y-1">
                    <h3 className="text-xs font-black uppercase tracking-widest text-white/40">Modalità Sviluppo</h3>
                    <p className="text-[10px] text-white/10 max-w-xs mx-auto italic leading-relaxed">
                        In questa sezione potrai testare direttamente le nuove skill e monitorare il consumo di token in tempo reale.
                    </p>
                </div>
                <button className="px-6 py-2 rounded-xl bg-white/5 border border-white/10 text-white/20 text-[9px] font-black uppercase tracking-widest hover:bg-white/10 transition-all mt-4">
                    Visualizza Payload Completo
                </button>
             </div>
          </div>
        )}
      </div>
    </div>
  )
}

function StatSimple({ icon, label, value }: { icon: ReactNode; label: string; value: number | string }) {
    return (
        <div className="flex items-center gap-1.5">
            <span className="text-white/20">{icon}</span>
            <span className="text-[10px] font-bold text-white/40">{label}:</span>
            <span className="text-[10px] font-black text-white/80">{value}</span>
        </div>
    )
}

function IntegrityRow({ label, status, score, danger = false }: { label: string, status: string, score: string, danger?: boolean }) {
    return (
        <div className="space-y-2">
            <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-widest">
                <span className="text-white/40">{label}</span>
                <span className={danger ? "text-red-400" : "text-emerald-400"}>{status} ({score})</span>
            </div>
            <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <div className={cn("h-full transition-all duration-1000", danger ? "bg-red-500 w-[20%]" : "bg-emerald-500 w-[100%]")} />
            </div>
        </div>
    )
}
