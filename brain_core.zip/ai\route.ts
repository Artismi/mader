import { anthropic } from '@ai-sdk/anthropic'
import { google } from '@ai-sdk/google'
import { streamText, convertToModelMessages, stepCountIs } from 'ai'
import { tool } from '@ai-sdk/provider-utils'
import { z } from 'zod'
import { skills, config, tasks, clients, ideas, quotes } from '@/lib/db'
import { initVaultWatcher, saveMemory } from '@/lib/vault'
import { DEFAULT_ARCHITECTURE } from '@/lib/ai/defaults'
import { buildContext } from '@/lib/ai/context'

export const maxDuration = 30

// Inizializza vault watcher se non già attivo
initVaultWatcher()

const taskSchema = z.object({
  title: z.string().describe("Il nome dell'incarico"),
  clientId: z.string().optional().describe('ID cliente se menzionato'),
  category: z.enum(['design', 'dev', 'bando', 'social', 'finanze', 'general']),
  deadlinePattern: z.string().describe('Data YYYY-MM-DD'),
})

const designElementSchema = z.object({
  id: z.string().optional(),
  type: z.enum(['rect', 'circle', 'text', 'line', 'image', 'path']),
  x: z.number().describe('Posizione X relativa alla tavola'),
  y: z.number().describe('Posizione Y relativa alla tavola'),
  w: z.number().optional(),
  h: z.number().optional(),
  color: z.string().optional().describe('Colore HEX fill'),
  stroke: z.string().optional().describe('Colore HEX bordo'),
  strokeWidth: z.number().optional().describe('Spessore bordo in px'),
  opacity: z.number().min(0).max(1).optional().describe('Opacità 0-1'),
  borderRadius: z.number().optional().describe('Raggio angoli (per rect)'),
  text: z.string().optional().describe('Testo per elementi text'),
  fontSize: z.number().optional().describe('Dimensione font in px'),
  fontFamily: z.string().optional().describe('Nome font Google Fonts (es. "Cormorant Garamond", "Bebas Neue")'),
  fontWeight: z.enum(['100','200','300','400','500','600','700','800','900']).optional(),
  fontStyle: z.enum(['normal','italic']).optional(),
  textAlign: z.enum(['left','center','right']).optional(),
  letterSpacing: z.number().optional().describe('Spaziatura lettere em (es. 0.1 = 10%)'),
  lineHeight: z.number().optional().describe('Interlinea moltiplicatore (es. 1.2)'),
  textTransform: z.enum(['uppercase','lowercase','capitalize','none']).optional(),
  gradient: z.object({
    type: z.enum(['linear','radial']).default('linear'),
    angle: z.number().optional().describe('Angolo gradi per linear'),
    stops: z.array(z.object({ offset: z.number(), color: z.string() })).describe('Stop colore, offset 0-1'),
  }).optional().describe('Gradiente alternativo a color (per rect/circle)'),
  url: z.string().optional().describe('URL immagine (per type=image)'),
  toId: z.string().optional().describe('ID dell\'elemento destinazione (per type=line/connector)'),
  zIndex: z.number().optional().describe('Ordine z (layer)'),
  shapeId: z.string().optional().describe(
    'Nome forma dalla libreria (per type=path). Esempi organici: "Blob 1","Blob 2","Amoeba","Fluid Wave","Melting Disc","Organic Mesh","Opple Liquid". ' +
    'Geometrici: "Sphere Wire","Iso Cube","Planet Ring","Prism 3D","Diamond Geo". ' +
    'Editoriali: "Swiss Cross","Brackets duo","Focus Mark","Rule Bold","L - Corner","Crosshair","Rule L","Bracket L","Bracket R","Corner". ' +
    'Brutalist: "Thorn A","Acid Sun","Jagged Star","Sharp Spike","Razor Edge","X Mark","Arrow Bold","Bold Bar","Spike". ' +
    'Tech: "Mirino Precisione","Circuito L","Grid Mini","Blueprint Box","Sfera Tecnica","Scanner","Orbit". ' +
    'Street: "Ink Splat","Urban Drip","Heavy Splat","Coffee Ring". ' +
    'Texture: "Dense Halftone","Gradient Dots".'
  ),
  pathData: z.string().optional().describe('SVG path data custom (spazio 0-100) — usato se shapeId non è sufficiente'),
  scaleShape: z.number().optional().describe('Moltiplicatore scala forma (default 1 = adatta a w/h)'),
})

const designBoardSchema = z.object({
  id: z.string().optional(),
  name: z.string().describe('Nome della tavola (es. "Identità", "Slide 1")'),
  width: z.number().default(1080),
  height: z.number().default(1080),
  backgroundColor: z.string().default('#ffffff'),
  elements: z.array(designElementSchema).optional().describe('Elementi grafici all\'interno della tavola'),
})

const DAY_MAP: Record<string, number> = {
  lunedi: 1, lun: 1, monday: 1, martedi: 2, mar: 2, tuesday: 2,
  mercoledi: 3, mer: 3, wednesday: 3, giovedi: 4, gio: 4, thursday: 4,
  venerdi: 5, ven: 5, friday: 5, sabato: 6, sab: 6, saturday: 6,
  domenica: 0, dom: 0, sunday: 0,
}

const recurringSchema = z.object({
  title: z.string(),
  days: z.array(z.string()),
  startHour: z.number().int().min(0).max(23),
  endHour: z.number().int().min(1).max(24),
  startDate: z.string(),
  endDate: z.string(),
})

/** Ultimo messaggio user: `parts` (UIMessage / useChat) oppure `content` legacy. */
function extractUserQueryFromMessages(messages: unknown): string {
  if (!Array.isArray(messages)) return ''
  const lastUser = [...messages].reverse().find(
    (m): m is Record<string, unknown> =>
      typeof m === 'object' && m !== null && m.role === 'user',
  )
  if (!lastUser) return ''

  const parts = lastUser.parts
  if (Array.isArray(parts)) {
    const fromParts = parts
      .filter(
        (p): p is { type?: string; text?: string } =>
          typeof p === 'object' && p !== null && (p as { type?: string }).type === 'text',
      )
      .map(p => (typeof p.text === 'string' ? p.text : ''))
      .join('')
    if (fromParts.trim()) return fromParts
  }

  const content = lastUser.content
  if (typeof content === 'string') return content
  if (Array.isArray(content)) {
    const first = content[0] as { text?: string } | undefined
    if (first && typeof first.text === 'string') return first.text
  }
  return ''
}

export async function POST(req: Request) {
  try {
    const { messages, modelId } = await req.json()
    console.log(`[AI-API] Request received: modelId=${modelId}, messagesCount=${messages?.length}`)


    if (modelId === 'gemini') {
      if (!process.env.GEMINI_API_KEY && !process.env.GOOGLE_GENERATIVE_AI_API_KEY) {
        return new Response(
          JSON.stringify({ error: 'Chiave Google/Gemini mancante in .env.local.' }),
          { status: 503, headers: { 'Content-Type': 'application/json' } },
        )
      }
    } else if (!process.env.ANTHROPIC_API_KEY) {
      return new Response(
        JSON.stringify({ error: 'ANTHROPIC_API_KEY mancante in .env.local' }),
        { status: 503, headers: { 'Content-Type': 'application/json' } },
      )
    }

    // 1. ASSEMBLE CONTEXT — stessa domanda che vede il modello, per RAG e match nome cliente
    const userQuery = extractUserQueryFromMessages(messages)

    const ctx = await buildContext(userQuery)

    // 2. SYSTEM PROMPT (CO-STAR Framework)
    const architecture = config.get('architecture') || DEFAULT_ARCHITECTURE
    const activeSkills = skills.getActive()
    const skillsBlock = activeSkills.map(s => s.content).filter(Boolean).join('\n\n---\n\n')

    const SYSTEM_PROMPT = [
      architecture,
      ctx.snapshot,
      '## Skill disponibili — istruzioni operative',
      skillsBlock,
      ctx.clientVaults.length > 0
        ? `\n\n---\n${ctx.clientVaults.join('\n\n---\n')}\n---`
        : '',
      ctx.activatedFiles.length > 0
        ? `\n\n---\n${ctx.activatedFiles.join('\n\n---\n')}\n---`
        : '',
      ctx.ragChunks.length > 0
        ? `\n\n---\n## Dal vault (Riferimenti rilevanti)\n${ctx.ragChunks.join('\n\n---\n')}\n---`
        : '',
      ctx.memories.length > 0
        ? `\n\n---\n## Ricordo (Fatti persistenti)\n${ctx.memories.join('\n')}\n---`
        : '',
    ].filter(Boolean).join('\n\n')
    const modelMessages = await convertToModelMessages(messages)

    const isGemini = modelId === 'gemini'
    const primaryModel = isGemini ? google('gemini-2.5-flash') : anthropic('claude-3-5-sonnet-20241022')
    const fallbackModel = anthropic('claude-3-5-sonnet-20241022')

    console.log(`[AI-API] Using model: ${isGemini ? 'gemini-2.5-flash' : 'claude-3-5-sonnet-20241022'}`)

    const streamArgs = {
      system: SYSTEM_PROMPT,
      messages: modelMessages,
      // Il default SDK è 1 step: dopo tool execute servono altri step per testo di chiusura.
      stopWhen: stepCountIs(15),
      tools: {
        createTask: tool({
          description: 'Crea un nuovo incarico nel sistema.',
          inputSchema: taskSchema,
          execute: async ({ title, category, deadlinePattern, clientId }: z.infer<typeof taskSchema>) => {
            let parsedDate = new Date()
            parsedDate.setDate(parsedDate.getDate() + 1)
            try {
              const d = new Date(deadlinePattern)
              if (!isNaN(d.getTime())) parsedDate = d
            } catch { /* usa default */ }

            tasks.create({
              client_id: clientId,
              title,
              type: category,
              category: 'task',
              status: 'todo',
              deadline: parsedDate.toISOString(),
            })

            return {
              success: true,
              message: `Incarico "${title}" creato per il ${parsedDate.toLocaleDateString('it-IT')}.`,
            }
          },
        }),

        createRecurringEngagement: tool({
          description: 'Crea slot ricorrenti per impegni fissi settimanali.',
          inputSchema: recurringSchema,
          execute: async ({ title, days, startHour, endHour, startDate, endDate }: z.infer<typeof recurringSchema>) => {
            const targetDays = days
              .map(d => DAY_MAP[d.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')])
              .filter((d): d is number => d !== undefined)

            if (targetDays.length === 0) return { success: false, message: 'Giorni non riconosciuti' }

            const durationMinutes = (endHour - startHour) * 60
            const start = new Date(startDate)
            const end = new Date(endDate)
            let count = 0

            for (const d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
              if (targetDays.includes(d.getDay())) {
                const deadline = new Date(d)
                deadline.setHours(startHour, 0, 0, 0)
                tasks.create({
                  title,
                  type: 'general',
                  category: 'engagement',
                  status: 'todo',
                  deadline: deadline.toISOString(),
                  duration_minutes: durationMinutes,
                })
                count++
              }
            }

            return {
              success: true,
              message: `Creati ${count} slot "${title}" (${startHour}:00–${endHour}:00) dal ${startDate} al ${endDate}.`,
            }
          },
        }),

        readTasks: tool({
          description: 'Legge gli incarichi dal sistema con filtri opzionali.',
          inputSchema: z.object({
            status: z.enum(['todo', 'in_progress', 'done', 'all']).optional(),
            category: z.string().optional(),
            clientId: z.string().optional(),
            limit: z.number().int().min(1).max(20).optional(),
          }),
          execute: async ({ status, category, clientId, limit }) => {
            const allTasks = tasks.getAll({
              status: status === 'all' ? undefined : status,
              category,
              clientId,
              limit: limit || 10,
            })
            if (allTasks.length === 0) return { success: true, message: 'Nessun task trovato.' }
            const formatted = allTasks.map(t => {
              const d = t.deadline ? new Date(t.deadline).toLocaleDateString('it-IT') : 'senza scadenza'
              return `[${t.id.slice(0, 8)}] ${t.title} — ${t.client_name || '—'} → ${d} [${t.status}]`
            }).join('\n')
            return { success: true, tasks: formatted }
          },
        }),

        updateTaskStatus: tool({
          description: 'Aggiorna lo stato di un incarico esistente.',
          inputSchema: z.object({
            taskId: z.string().describe('ID parziale del task (almeno 8 caratteri)'),
            newStatus: z.enum(['todo', 'in_progress', 'done']),
          }),
          execute: async ({ taskId, newStatus }) => {
            const allTasks = tasks.getAll({ limit: 100 })
            const match = allTasks.find(t => t.id.startsWith(taskId))
            if (!match) return { success: false, message: `Task ${taskId} non trovato.` }
            tasks.update(match.id, { status: newStatus })
            return { success: true, message: `Task "${match.title}" aggiornato a ${newStatus}.` }
          },
        }),

        createIdea: tool({
          description: 'Cattura una nuova idea creativa nel sistema.',
          inputSchema: z.object({
            text: z.string().describe("Il contenuto dell'idea"),
            title: z.string().optional(),
            clientId: z.string().optional(),
            platforms: z.array(z.string()).optional(),
          }),
          execute: async ({ text, title, clientId, platforms }) => {
            const idea = ideas.create({
              client_id: clientId,
              text,
              title,
              platforms: platforms || [],
              idea_status: 'nuova',
              assigned: false,
              output_links: []
            })
            return { success: true, message: `Idea "${title || text.slice(0, 20)}" salvata con successo.`, id: idea.id }
          }
        }),

        searchClient: tool({
          description: 'Cerca un cliente nel vault per recuperare dettagli brand o progetto.',
          inputSchema: z.object({ name: z.string() }),
          execute: async ({ name }) => {
            const allClients = clients.getAll()
            const matches = allClients.filter(c => c.name.toLowerCase().includes(name.toLowerCase()))
            if (matches.length === 0) return { success: false, message: `Nessun cliente trovato per "${name}"` }
            return {
              success: true,
              clients: matches.map(c => `[${c.id.slice(0, 8)}] ${c.name} (${c.sector || 'settore non specificato'})`).join('\n')
            }
          }
        }),

        remember: tool({
          description: 'Memorizza un fatto persistente o una preferenza del cliente nel sistema (Memory).',
          inputSchema: z.object({
            content: z.string().describe('Il fatto da ricordare'),
            contextType: z.enum(['client', 'global']).default('global'),
            contextId: z.string().optional(),
          }),
          execute: async ({ content, contextType, contextId }) => {
            await saveMemory(content, contextType, contextId)
            return { success: true, message: `Ricordato: "${content}"` }
          },
        }),

        createFinancialDocument: tool({
          description: 'Crea un preventivo o una fattura nel sistema basandosi sui dettagli forniti dal cliente o discussi.',
          inputSchema: z.object({
            type: z.enum(['preventivo', 'fattura']),
            clientId: z.string().describe('ID del cliente'),
            title: z.string().describe('Oggetto del documento (es. "Sviluppo sito web")'),
            items: z.array(z.object({
              desc: z.string(),
              qty: z.number().min(1).default(1),
              unitPrice: z.number().min(0)
            })).describe('Elenco delle voci di spesa dettagliate'),
            notes: z.string().optional().describe('Note aggiuntive, scadenze o termini di pagamento'),
          }),
          execute: async ({ type, clientId, title, items, notes }) => {
            const client = clients.getById(clientId)
            if (!client) return { success: false, message: 'Cliente non trovato. Usa searchClient per trovare l\'ID corretto.' }
            
            const doc = quotes.create({
              client_id: clientId,
              client_name: client.name,
              title,
              number: quotes.nextNumber(type),
              type,
              status: 'bozza',
              items: items.map(i => ({ desc: i.desc, qty: i.qty, unit_price: i.unitPrice })),
              total: items.reduce((s, i) => s + i.qty * i.unitPrice, 0),
              notes,
              issued_at: new Date().toISOString().split('T')[0],
            })
            
            return {
              success: true,
              message: `${type === 'preventivo' ? 'Preventivo' : 'Fattura'} #${doc.number} per "${title}" creato e salvato in Bozza.`,
              id: doc.id
            }
          }
        }),

        getCanvasState: tool({
          description: 'Legge lo stato attuale del canvas: tavole esistenti e i loro elementi. Usalo prima di creare o aggiornare un design per capire cosa c\'è già sulla tavola e applicare stile coerente.',
          inputSchema: z.object({
            boardId: z.string().optional().describe('ID tavola specifica. Ometti per leggere tutte le tavole.'),
          }),
          execute: async () => {
            return {
              success: true,
              message: 'Canvas state sarà iniettato dal frontend. Questo tool segnala al client di inviare lo snapshot del canvas.',
              requestCanvasState: true,
            }
          },
        }),

        updateCanvasElements: tool({
          description: 'Aggiorna elementi esistenti su una tavola del canvas (cambia font, colori, testo, posizione). Usa gli ID degli elementi letti con getCanvasState.',
          inputSchema: z.object({
            boardId: z.string().describe('ID della tavola da modificare'),
            updates: z.array(z.object({
              id: z.string().describe('ID elemento da aggiornare'),
              changes: designElementSchema.partial().describe('Proprietà da modificare (solo quelle che cambiano)'),
            })).describe('Lista aggiornamenti elemento'),
          }),
          execute: async ({ boardId, updates }) => {
            return {
              success: true,
              message: `Aggiornati ${updates.length} elementi sulla tavola ${boardId}.`,
              boardId,
              updates,
            }
          },
        }),

        createDesignBoards: tool({
          description: 'Crea una o più tavole (artboard) nel Creative Studio con elementi grafici, schemi o layout di slide.',
          inputSchema: z.object({
            projectId: z.string().optional().describe('ID del progetto di design attivo (se presente)'),
            boards: z.array(designBoardSchema),
            layout: z.enum(['strip', 'grid', 'free']).default('strip').describe('Layout di disposizione delle tavole sul canvas'),
          }),
          execute: async ({ boards, layout }) => {
            // Questo tool ritorna la struttura che il frontend userà per "disegnare" sul canvas in tempo reale.
            return {
              success: true,
              message: `Generate ${boards.length} tavole con layout ${layout}.`,
              boards,
              layout
            }
          }
        }),

        generateAIImage: tool({
          description: 'Genera un\'immagine tramite IA e restituisce il suo URL. IMPORTANTE: questo tool NON aggiunge l\'immagine al canvas — devi usare l\'imageUrl restituito come valore del campo `url` di un elemento type:"image" dentro createDesignBoards.',
          inputSchema: z.object({
            prompt: z.string().describe('Descrizione dettagliata dell\'immagine da generare'),
            aspectRatio: z.enum(['1:1', '16:9', '9:16']).default('1:1'),
          }),
          execute: async ({ prompt, aspectRatio }) => {
            const seed = Math.floor(Math.random() * 1000000)
            const width = aspectRatio === '16:9' ? 1280 : aspectRatio === '9:16' ? 720 : 1024
            const height = aspectRatio === '16:9' ? 720 : aspectRatio === '9:16' ? 1280 : 1024

            const pollinationsUrl = `https://pollinations.ai/p/${encodeURIComponent(prompt)}?width=${width}&height=${height}&seed=${seed}&nologo=true&model=flux`
            const imageUrl = `/api/proxy-image?url=${encodeURIComponent(pollinationsUrl)}`

            return {
              success: true,
              imageUrl,
              prompt
            }
          }
        }),

        clearBoard: tool({
          description: 'Rimuove tutti gli elementi dalla tavola specificata (lascia la tavola artboard vuota). Usalo prima di ricreare un design da zero, o quando l\'utente chiede "ricrea", "rifai", "riparti da zero".',
          inputSchema: z.object({
            boardName: z.string().describe('Nome della tavola da svuotare (es. "Poster Evento", "Slide 1")'),
          }),
          execute: async ({ boardName }) => {
            return {
              success: true,
              message: `Tavola "${boardName}" svuotata.`,
              boardName,
            }
          },
        }),

        deleteElements: tool({
          description: 'Elimina elementi specifici dal canvas per ID. Usa gli ID degli elementi letti con getCanvasState.',
          inputSchema: z.object({
            elementIds: z.array(z.string()).describe('Lista di ID degli elementi da eliminare'),
          }),
          execute: async ({ elementIds }) => {
            return {
              success: true,
              message: `Eliminati ${elementIds.length} elementi.`,
              elementIds,
            }
          },
        }),
      },
    }

    try {
      const result = streamText({ model: primaryModel, ...streamArgs })
      return result.toUIMessageStreamResponse()
    } catch (streamErr: unknown) {
      const errMsg = streamErr instanceof Error ? streamErr.message : String(streamErr)
      const isQuotaError = errMsg.includes('quota') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('rate') || errMsg.includes('429')
      if (isGemini && isQuotaError && process.env.ANTHROPIC_API_KEY) {
        console.warn('[AI-API] Gemini quota esaurita, fallback a Claude:', errMsg)
        const result = streamText({ model: fallbackModel, ...streamArgs })
        return result.toUIMessageStreamResponse()
      }
      throw streamErr
    }

  } catch (err: unknown) {
    console.error("[AI-API] Global Error:", err)
    const msg = err instanceof Error ? err.message : String(err)
    const isQuota = msg.includes('quota') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('exceeded')
    return new Response(JSON.stringify({
      error: isQuota
        ? 'Quota Gemini esaurita. Passa a Claude oppure abilita la fatturazione su Google AI Studio.'
        : `AI Error: ${msg}`
    }), {
      status: isQuota ? 429 : 500,
      headers: { 'Content-Type': 'application/json' },
    })
  }
}