import { CervelloDashboard } from '@/components/ui/cervello-dashboard'

export default function CervelloPage() {
  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden bg-black px-3 py-2 sm:px-4">
      <CervelloDashboard />
    </div>
  )
}
